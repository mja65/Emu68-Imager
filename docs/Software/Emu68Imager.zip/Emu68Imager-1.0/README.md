# Emu68Imager

Quick and dirty instructions:

1. Extract to a folder with all the subfolders.
2. Run the PistormImagerGui.cmd file by double clicking on it.