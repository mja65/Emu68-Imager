c:Emu68Info Board
Wait