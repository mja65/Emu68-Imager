# Emu68Imager

Documentation is available at:

https://mja65.github.io/Emu68-Imager/

Quick and dirty instructions:

1. Extract to a folder with all the subfolders.
2. Run the PistormImagerGui.cmd file by double clicking on it.
